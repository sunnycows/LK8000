XML Dialogs for LK8000 
Copy a template from templates here, it will be used in place of the internals.
file.xml is for landscape
file_L.xml is for portrait  (Yes, they are inverted so far)


