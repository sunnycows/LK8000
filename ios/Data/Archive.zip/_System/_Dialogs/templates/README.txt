These are the templates for dialogs used internally by lk8000.
You can customize them, by copying a template inside its relative aircraft mode.

Changing a template in this folder will NOT affect anything: you must copy it into
an aircraft mode folder , like GLIDER for example.

Configuration templates are 100% taken from aircraft folders, not internally.
For this reason, do NOT remove them.

