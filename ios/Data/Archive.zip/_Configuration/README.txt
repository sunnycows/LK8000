_Configuration  subdirectory

Contents:

IDFLARM.txt  	flarm ids, user editable. When you rename a device on the fly from LK8000, its name
		is saved inside this file, also.

FLARMNET.FLN	flarmnets IDs, not editable. Download them from www.flarmnet.org and choose
		Winpilot format. Save it with this name and replace. It is automatically loaded
		on startup. Do this only if you have a flarm connection available of course!

NOTEPAD.txt	Notes available inside menu info, user editable

History.txt	created by software, for GOTO waypoints history DO NOT EDIT


**** DO NOT COPY HERE DEFAULT_PROFILE  from an old version of LK
     or from another device! 


Updated 100721